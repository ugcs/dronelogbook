#!/bin/sh
java -Xmx1024m -Xdock:icon=${0%/*}/../Resources/logo.png -jar ${0%/*}/*.jar ExecutedFromLauncher