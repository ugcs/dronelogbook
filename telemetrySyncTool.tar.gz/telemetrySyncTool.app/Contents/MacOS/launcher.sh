#!/bin/sh
java -jar ${0%/*}/*.jar