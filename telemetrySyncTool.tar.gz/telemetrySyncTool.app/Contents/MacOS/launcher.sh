#!/bin/sh
java -Xmx6144m -Xdock:icon=${0%/*}/../Resources/logo.png -jar ${0%/*}/*.jar ExecutedFromLauncher