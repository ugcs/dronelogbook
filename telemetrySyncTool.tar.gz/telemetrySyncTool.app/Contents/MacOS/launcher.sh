#!/bin/sh
java -Xmx4096m -Xdock:icon=${0%/*}/../Resources/logo.png -jar ${0%/*}/*.jar ExecutedFromLauncher