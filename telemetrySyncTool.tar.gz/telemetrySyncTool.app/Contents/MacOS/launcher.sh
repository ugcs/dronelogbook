#!/bin/sh
java -Xmx1024m -jar ${0%/*}/*.jar ExecutedFromLauncher